return {
    LrSdkVersion = 6.0,
    LrSdkMinimumVersion = 6.0,
    LrToolkitIdentifier = 'dolje_uprava',
    LrPluginName = "Plavi filter v0.1",
    LrPluginInfoProvider = "test.lua",
    LrExportServiceProvider = {
        title = "Plavi filter",
        file = "plavifilter.lua",
        builtInPresetsDir = "KSET_PRESETS",
  },
}